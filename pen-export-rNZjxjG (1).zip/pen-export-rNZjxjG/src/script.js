function myFunction() {
  //alert("Thanks for Visiting !!")
let header= 
(document.getElementById("header").style.color="red");
}